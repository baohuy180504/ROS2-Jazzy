import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from PIL import Image, ImageTk
import cv2
import torch
import numpy as np
import yaml
import os
import sys
import time

# Import MobileIE
from model import import_model

# Import YOLO
try:
    from ultralytics import YOLO
except ImportError:
    messagebox.showerror("Thiếu thư viện", "Chưa cài YOLO. Chạy lệnh: uv pip install ultralytics")
    sys.exit()

class WebcamAutoGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Night Vision AI - AUTO SWITCH MODE (FIXED THRESHOLD)")
        self.root.geometry("1350x950")

        # --- SETUP MODEL ---
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.net_enhance = self.load_enhance_model()
        self.model_yolo = None 
        self.is_running = False 
        self.cap = None 
        
        # --- CẤU HÌNH NGƯỠNG CỐ ĐỊNH ---
        self.FIXED_THRESHOLD = 50  # <--- ĐÃ CHỈNH CỐ ĐỊNH TẠI ĐÂY

        # --- GIAO DIỆN ---
        header = tk.Frame(root, bg="#2c3e50", height=70)
        header.pack(fill="x")
        tk.Label(header, text="CAMERA PRO: ANTI-NOISE & NIGHT VISION", 
                 fg="white", bg="#2c3e50", font=("Segoe UI", 18, "bold")).pack(pady=15)

        # CONTROL PANEL
        control_frame = tk.Frame(root, pady=10, bg="#ecf0f1")
        control_frame.pack(fill="x")

        # Hàng 1: Nút bấm
        row1 = tk.Frame(control_frame, bg="#ecf0f1")
        row1.pack(pady=5)

        self.btn_weights = tk.Button(row1, text="1. CHỌN FILE YOLO (.pt)", 
                                     bg="#8e44ad", fg="white", font=("Segoe UI", 10, "bold"),
                                     command=self.load_yolo_weights)
        self.btn_weights.pack(side="left", padx=15)

        tk.Label(row1, text="Cam ID:", bg="#ecf0f1").pack(side="left")
        self.ent_cam_id = tk.Entry(row1, width=3, font=("Segoe UI", 12))
        self.ent_cam_id.insert(0, "0") 
        self.ent_cam_id.pack(side="left", padx=5)

        self.btn_start = tk.Button(row1, text="2. BẬT CAMERA", 
                                  bg="#27ae60", fg="white", font=("Segoe UI", 10, "bold"),
                                  command=self.start_camera)
        self.btn_start.pack(side="left", padx=15)

        self.btn_stop = tk.Button(row1, text="⏹ DỪNG", 
                                  bg="#c0392b", fg="white", font=("Segoe UI", 10, "bold"),
                                  state="disabled",
                                  command=self.stop_camera)
        self.btn_stop.pack(side="left", padx=15)

        self.btn_settings = tk.Button(row1, text="🔧 MỞ CÀI ĐẶT GỐC", 
                                      bg="#d35400", fg="white", font=("Segoe UI", 10, "bold"),
                                      state="disabled",
                                      command=self.open_camera_settings)
        self.btn_settings.pack(side="left", padx=15)

        # Hàng 2: HIỂN THỊ THÔNG SỐ (Đã bỏ thanh trượt)
        row2 = tk.Frame(control_frame, bg="#ecf0f1")
        row2.pack(pady=10, fill="x")

        # Hiển thị độ sáng hiện tại
        self.lbl_curr_brightness = tk.Label(row2, text="Độ sáng thực tế: 0", font=("Arial", 12), bg="#ecf0f1", fg="blue")
        self.lbl_curr_brightness.pack(side="left", padx=30)
        
        # Hiển thị chế độ
        self.lbl_mode = tk.Label(row2, text="CHẾ ĐỘ: ---", font=("Arial", 12, "bold"), bg="#ecf0f1", fg="gray")
        self.lbl_mode.pack(side="left", padx=30)

        # Hiển thị FPS
        self.lbl_fps = tk.Label(row2, text="FPS: 0", fg="red", bg="#ecf0f1", font=("Arial", 12, "bold"))
        self.lbl_fps.pack(side="right", padx=30)

        # KHUNG HIỂN THỊ VIDEO
        self.video_frame = tk.Label(root, bg="black", text="Màn hình hiển thị", fg="gray")
        self.video_frame.pack(expand=True, fill="both", padx=10, pady=10)

    def load_enhance_model(self):
        try:
            class Args: pass
            opt = Args()
            opt.task = 'test'
            opt.model_task = 'lle'
            opt.device = 'cuda' if torch.cuda.is_available() else 'cpu'
            
            config_path = 'config/lle.yaml'
            if not os.path.exists(config_path):
                messagebox.showerror("Lỗi", "Không tìm thấy file config/lle.yaml")
                sys.exit()

            with open(config_path, 'r') as f:
                opt.config = yaml.safe_load(f)

            print(f"Loading MobileIE on {opt.device}...")
            net = import_model(opt)
            net.eval()
            return net
        except Exception as e:
            messagebox.showerror("Lỗi Model", str(e))
            sys.exit()

    def load_yolo_weights(self):
        path = filedialog.askopenfilename(filetypes=[("YOLO Weights", "*.pt")])
        if not path: return
        try:
            self.model_yolo = YOLO(path)
            messagebox.showinfo("OK", f"Đã nạp: {os.path.basename(path)}")
        except Exception as e:
            messagebox.showerror("Lỗi YOLO", str(e))

    def open_camera_settings(self):
        if self.cap is not None and self.cap.isOpened():
            self.cap.set(cv2.CAP_PROP_SETTINGS, 1)

    def stop_camera(self):
        self.is_running = False

    def increase_saturation(self, img, factor=1.5):
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        h, s, v = cv2.split(hsv)
        s = s.astype(np.float32) * factor
        s = np.clip(s, 0, 255).astype(np.uint8)
        final_hsv = cv2.merge([h, s, v])
        img_saturated = cv2.cvtColor(final_hsv, cv2.COLOR_HSV2BGR)
        return img_saturated
    
    def calculate_brightness(self, image):
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        return int(np.mean(gray))

    def start_camera(self):
        try:
            cam_id = int(self.ent_cam_id.get())
        except ValueError:
            return

        self.is_running = True
        self.btn_start.config(state="disabled")
        self.btn_weights.config(state="disabled")
        self.btn_stop.config(state="normal")
        self.btn_settings.config(state="normal") 
        self.root.update()

        try:
            self.cap = cv2.VideoCapture(cam_id, cv2.CAP_DSHOW)
            
            if not self.cap.isOpened(): 
                print("DSHOW failed, falling back to default...")
                self.cap = cv2.VideoCapture(cam_id)
            
            if not self.cap.isOpened(): raise ValueError(f"Không mở được Camera {cam_id}")

            # --- SETUP CỐ ĐỊNH THÔNG SỐ CAMERA (Hardware) ---
            self.cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, 0) 
            self.cap.set(cv2.CAP_PROP_GAIN, 100) # Gain cao (như code cũ bạn gửi)
            self.cap.set(cv2.CAP_PROP_EXPOSURE, 0) # Exposure 0 (như code cũ bạn gửi)
            # -----------------------------------------------

            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            
            width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            
            target_classes = [0, 1, 2, 3, 5, 7]
            
            frame_count = 0
            last_final_view = None
            prev_time = time.time()

            with torch.no_grad():
                while self.is_running:
                    ret, frame = self.cap.read()
                    if not ret: break

                    frame_count += 1
                    
                    # 1. ĐO ĐỘ SÁNG
                    curr_brightness = self.calculate_brightness(frame)
                    
                    # --- SỬ DỤNG NGƯỠNG CỐ ĐỊNH 50 ---
                    threshold = self.FIXED_THRESHOLD 
                    
                    if frame_count % 5 == 0:
                        self.lbl_curr_brightness.config(text=f"Độ sáng thực tế: {curr_brightness}")

                    # 2. XỬ LÝ (Frame Skipping)
                    if frame_count % 2 == 0 or last_final_view is None:
                        
                        # --- LOGIC XỬ LÝ ẢNH ---
                        if curr_brightness < threshold:
                            self.lbl_mode.config(text=f"CHẾ ĐỘ: ĐÊM (AI ON) | Ngưỡng < {threshold}", fg="green")
                            
                            # MedianBlur lọc nhiễu
                            frame_clean = cv2.medianBlur(frame, 3) 
                            
                            # Resize cho AI MobileIE
                            h_orig, w_orig = frame_clean.shape[:2]
                            ai_w = (w_orig // 32) * 32
                            ai_h = (h_orig // 32) * 32
                            img_resized = cv2.resize(frame_clean, (ai_w, ai_h))
                            
                            img_in = cv2.cvtColor(img_resized, cv2.COLOR_BGR2RGB)
                            img_in = img_in.astype(np.float32) / 255.0
                            img_tensor = torch.from_numpy(img_in).permute(2, 0, 1).unsqueeze(0).to(self.device)

                            output = self.net_enhance(img_tensor)
                            if isinstance(output, (list, tuple)): output = output[0]

                            output = output.squeeze(0).cpu().permute(1, 2, 0).numpy()
                            output = np.clip(output, 0, 1)
                            output = (output * 255).astype(np.uint8)
                            enhanced_bgr = cv2.cvtColor(output, cv2.COLOR_RGB2BGR)

                            final_frame = self.increase_saturation(enhanced_bgr, factor=1.4)
                            
                        else:
                            self.lbl_mode.config(text=f"CHẾ ĐỘ: NGÀY (AI OFF) | Ngưỡng > {threshold}", fg="red")
                            final_frame = cv2.resize(frame, (width, height))

                        # 3. NHẬN DIỆN YOLO
                        final_view = final_frame
                        if self.model_yolo is not None:
                            results = self.model_yolo.predict(final_frame, classes=target_classes, conf=0.25, verbose=False)
                            final_view = results[0].plot()
                        
                        last_final_view = final_view
                    else:
                        final_view = last_final_view

                    # DISPLAY
                    final_view_resized = cv2.resize(final_view, (width, height))
                    combined = np.hstack((frame, final_view_resized))

                    display_scale = 1.3
                    d_w = int(combined.shape[1] * display_scale)
                    d_h = int(combined.shape[0] * display_scale)
                    
                    if d_w > 1250:
                        ratio = 1250 / d_w
                        d_w = 1250
                        d_h = int(d_h * ratio)
                        
                    combined_display = cv2.resize(combined, (d_w, d_h))

                    img_pil = Image.fromarray(cv2.cvtColor(combined_display, cv2.COLOR_BGR2RGB))
                    img_tk = ImageTk.PhotoImage(img_pil)

                    self.video_frame.config(image=img_tk, text="")
                    self.video_frame.image = img_tk
                    
                    curr_time = time.time()
                    fps = 1 / (curr_time - prev_time) if (curr_time - prev_time) > 0 else 30
                    prev_time = curr_time
                    if frame_count % 10 == 0:
                        self.lbl_fps.config(text=f"FPS: {int(fps)}")
                    
                    self.root.update()

            self.cap.release()

        except Exception as e:
            messagebox.showerror("Lỗi Runtime", str(e))
        finally:
            self.btn_start.config(state="normal")
            self.btn_weights.config(state="normal")
            self.btn_stop.config(state="disabled")
            self.btn_settings.config(state="disabled")
            self.is_running = False

if __name__ == "__main__":
    root = tk.Tk()
    app = WebcamAutoGUI(root)
    root.mainloop()