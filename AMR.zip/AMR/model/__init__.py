import torch
from importlib import import_module
from .lle import MobileIELLENet, MobileIELLENetS
from .isp import MobileIEISPNet, MobileIEISPNetS

__all__ = {
    'MobileIELLENet',
    'MobileIELLENetS',
    'MobileIEISPNet', 
    'MobileIEISPNetS',
    'import_model'
}

def import_model(opt):
    model_name = 'MobileIE'+opt.model_task.upper()
    kwargs = {'channels': opt.config['model']['channels']}

    if opt.config['model']['type'] == 're-parameterized':
        model_name += 'NetS'
    elif opt.config['model']['type'] == 'original':
        model_name += 'Net'
        kwargs['rep_scale'] = opt.config['model']['rep_scale']
    else:
        raise ValueError('unknown model type, please choose from [original, re-parameterized]')

    model = getattr(import_module('model'), model_name)(**kwargs)
    # --- CHÈN ĐOẠN NÀY ĐỂ KIỂM TRA ---
    import torch
    import os
    print("\n" + "="*30)
    print(f"DEBUG: opt.device = '{opt.device}'")
    print(f"DEBUG: CUDA_VISIBLE_DEVICES = '{os.environ.get('CUDA_VISIBLE_DEVICES')}'")
    print(f"DEBUG: Torch sees CUDA? {torch.cuda.is_available()}")
    print(f"DEBUG: GPU Count = {torch.cuda.device_count()}")
    print("="*30 + "\n")
    # ---------------------------------

    
    model = model.to(opt.device)

    if opt.config['model']['pretrained']:
        #model.load_state_dict(torch.load(opt.config['model']['pretrained']))
        model.load_state_dict(torch.load(opt.config['model']['pretrained']), strict=False)

    if opt.config['model']['type'] == 'original' and opt.config['model']['need_slim'] is True:
        model = model.slim().to(opt.device)
    return model
