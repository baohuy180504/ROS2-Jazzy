import cv2

def nothing(x):
    pass

# Mở camera với DirectShow để chỉnh tham số
cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)

# Tạo cửa sổ điều khiển
cv2.namedWindow('Calibration')

# Tạo thanh trượt cho Exposure (Phơi sáng)
# Thang đo thường từ -13 đến 0 (trên Windows)
cv2.createTrackbar('Exposure', 'Calibration', 5, 13, nothing)

# Tạo thanh trượt cho Gain (Độ nhạy - Nhiễu)
# Thang đo thường từ 0 đến 255
cv2.createTrackbar('Gain', 'Calibration', 0, 255, nothing)

print("Điều chỉnh thanh trượt để tìm thông số đẹp nhất!")
print("Nhấn 'q' để thoát.")

while True:
    # Lấy giá trị từ thanh trượt
    # Vì thanh trượt OpenCV không hỗ trợ số âm, ta lấy giá trị dương rồi trừ đi
    # VD: Kéo số 5 -> Exposure = -5. Kéo số 10 -> Exposure = -10
    exp_val = cv2.getTrackbarPos('Exposure', 'Calibration')
    gain_val = cv2.getTrackbarPos('Gain', 'Calibration')

    # Cập nhật camera
    # Lưu ý: Exposure trên Windows thường là số ÂM
    cap.set(cv2.CAP_PROP_EXPOSURE, -exp_val) 
    cap.set(cv2.CAP_PROP_GAIN, gain_val)

    ret, frame = cap.read()
    if not ret:
        break

    # Hiển thị thông số lên hình
    cv2.putText(frame, f"Exp: {-exp_val} | Gain: {gain_val}", (10, 30), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

    cv2.imshow('Calibration', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()