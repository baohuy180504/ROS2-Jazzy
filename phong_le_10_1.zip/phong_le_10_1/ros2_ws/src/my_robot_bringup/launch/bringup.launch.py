import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node

def generate_launch_description():

    # ================== URDF ==================
    desc_pkg = get_package_share_directory('amr_description')
    urdf_file = os.path.join(desc_pkg, 'urdf', 'amr.urdf')

    # Đọc nội dung URDF
    with open(urdf_file, 'r') as f:
        robot_description = f.read()

    # ================== ROBOT STATE PUBLISHER ==================
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': robot_description
        }]
    )

    # ================== LIDAR ==================
    lidar_node = Node(
        package='sllidar_ros2',
        executable='sllidar_node',
        name='sllidar_node',
        parameters=[{
            'channel_type': 'serial',
            'serial_port': '/dev/ttyUSB0',
            'serial_baudrate': 115200,
            'frame_id': 'laser_frame',
            'inverted': False,
            'angle_compensate': True,
            'scan_mode': 'Sensitivity'
        }],
        output='screen'
    )

    # ================== REAL DRIVER ==================
    real_driver_path = os.path.join(
        os.getenv('HOME'),
        'phong_le_10_1/ros2_ws/src/my_robot_base_driver/scripts/real_driver.py'
    )

    real_driver = ExecuteProcess(
        cmd=['python3', real_driver_path],
        output='screen'
    )

    return LaunchDescription([
        robot_state_publisher,
        lidar_node,
        real_driver
    ])
