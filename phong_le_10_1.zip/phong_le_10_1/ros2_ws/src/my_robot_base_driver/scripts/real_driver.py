#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, TransformStamped, Quaternion
from nav_msgs.msg import Odometry
from tf2_ros import TransformBroadcaster
import serial
import math
import time

# --- CẤU HÌNH (CALIBRATION) ---
WHEEL_DIAMETER = 0.067  # 6.5 cm
PPR_MOTOR = 11.0        # 11 xung/vòng động cơ
GEAR_RATIO = 45.0       # Tỉ số truyền 1:45
BASE_WIDTH = 0.24       # Khoảng cách 2 bánh 24cm

LEFT_WHEEL_SCALE = 1.0
RIGHT_WHEEL_SCALE = 1.025   # bù bánh phải chậm ~2.5%

# Tính toán tự động
TICKS_PER_REV = PPR_MOTOR * GEAR_RATIO 
WHEEL_CIRCUMFERENCE = 3.14159265 * WHEEL_DIAMETER 
TICKS_PER_METER = TICKS_PER_REV / WHEEL_CIRCUMFERENCE 

class RealRobotDriver(Node):
    def __init__(self):
        super().__init__('real_robot_driver')
        
        # 1. Kết nối Serial (Lưu ý: Sửa đúng cổng USB của bạn)
        try:
            # Nếu bạn dùng ttyUSB1 thì giữ nguyên, nếu USB0 thì sửa lại
            self.ser = serial.Serial('/dev/ttyUSB1', 115200, timeout=0.1)
            self.get_logger().info('Da ket noi Serial thanh cong!')
        except Exception as e:
            self.get_logger().error(f'Khong the ket noi Serial: {e}')
            # Không exit để tránh crash ROS, chỉ báo lỗi
            self.ser = None

        # 2. Publisher & Subscriber
        self.sub_cmd = self.create_subscription(Twist, 'cmd_vel', self.cmd_vel_callback, 10)
        self.pub_odom = self.create_publisher(Odometry, 'odom', 10)
        self.tf_broadcaster = TransformBroadcaster(self)

        # 3. Timer 20Hz
        self.create_timer(0.05, self.read_serial_callback)

        # 4. Biến Odometry
        self.x = 0.0
        self.y = 0.0
        self.th = 0.0
        
        self.last_left_ticks = 0
        self.last_right_ticks = 0
        self.first_run = True
        self.last_time = self.get_clock().now()

    def normalize_angle(self, angle):
        while angle > math.pi:
            angle -= 2.0 * math.pi
        while angle < -math.pi:
            angle += 2.0 * math.pi
        return angle

    def cmd_vel_callback(self, msg):
        if self.ser is None: return
        v = msg.linear.x
        w = msg.angular.z
        cmd = f"{v:.2f},{w:.2f}\n"
        try:
            self.ser.write(cmd.encode('utf-8'))
        except Exception as e:
            pass

    def read_serial_callback(self):
        if self.ser is None: return
        try:
            if self.ser.in_waiting > 0:
                line = self.ser.readline().decode('utf-8', errors='ignore').strip()
                self.get_logger().info(f"RAW SERIAL: {line}")  # Debug raw data từ Arduino
                if line.startswith('e:'):
                    parts = line.split(':')[1].split(',')
                    if len(parts) == 2:
                        try:
                            left_ticks = int(parts[0])
                            right_ticks = int(parts[1])  # Giữ đảo chiều nếu cần
                            self.get_logger().info(f"TICKS RECEIVED: L={left_ticks}, R={right_ticks}, DELTA_L={left_ticks - self.last_left_ticks}, DELTA_R={right_ticks - self.last_right_ticks}")
                            self.calculate_odometry(left_ticks, right_ticks)
                        except ValueError:
                            self.get_logger().warn(f"Invalid ticks format: {line}")
                    else:
                        self.get_logger().warn(f"Invalid parts: {line}")
                else:
                    self.get_logger().warn(f"Non-encoder line: {line}")
            else:
                self.get_logger().warn("No serial data this cycle")
        
        # Fallback: Luôn publish odom (dùng last_ticks để tính dt, giữ pose cũ nếu no delta)
        # Điều này đảm bảo TF/odom update 20Hz, tránh extrapolation error ở AMCL
            self.calculate_odometry(self.last_left_ticks, self.last_right_ticks)
    
        except Exception as e:
            self.get_logger().error(f"Serial read error: {e}")
    
    def calculate_odometry(self, left_ticks, right_ticks):
        current_time = self.get_clock().now()
        dt = (current_time - self.last_time).nanoseconds / 1e9
        
        # Tránh dt = 0 gây chia cho 0
        if dt < 0.001: return 

        if self.first_run:
            self.last_left_ticks = left_ticks
            self.last_right_ticks = right_ticks
            self.first_run = False
            self.last_time = current_time
            return

        # 1. Tính delta (CÓ SCALE)
        d_left = (left_ticks - self.last_left_ticks) / TICKS_PER_METER
        d_right = (right_ticks - self.last_right_ticks) / TICKS_PER_METER

        d_left *= LEFT_WHEEL_SCALE
        d_right *= RIGHT_WHEEL_SCALE

        self.last_left_ticks = left_ticks
        self.last_right_ticks = right_ticks
        self.last_time = current_time

        d_center = (d_left + d_right) / 2.0
        d_theta = (d_right - d_left) / BASE_WIDTH

        # 2. Cập nhật Pose
        self.x += d_center * math.cos(self.th)
        self.y += d_center * math.sin(self.th)
        self.th += d_theta
        self.th = self.normalize_angle(self.th)
        # 3. Tạo Quaternion
        q = self.euler_to_quaternion(0, 0, self.th)

        # 4. Publish TF (QUAN TRỌNG: Odom -> base_link)
        t = TransformStamped()
        t.header.stamp = current_time.to_msg()
        t.header.frame_id = 'odom'
        t.child_frame_id = 'base_link'
        t.transform.translation.x = self.x
        t.transform.translation.y = self.y
        t.transform.translation.z = 0.0
        t.transform.rotation = q
        self.tf_broadcaster.sendTransform(t)

        # 5. Publish Odom Message (Với COVARIANCE)
        odom = Odometry()
        odom.header.stamp = current_time.to_msg()
        odom.header.frame_id = 'odom'
        odom.child_frame_id = 'base_link'
        odom.pose.pose.position.x = self.x
        odom.pose.pose.position.y = self.y
        odom.pose.pose.orientation = q
        
        # Vận tốc
        vx = d_center / dt
        vth = d_theta / dt
        odom.twist.twist.linear.x = vx
        odom.twist.twist.angular.z = vth

        # --- QUAN TRỌNG: THÊM COVARIANCE ---
        # SLAM Toolbox cần cái này để biết dữ liệu tin cậy đến đâu
        # Dạng mảng 36 phần tử. Ta đặt sai số nhỏ (0.01) cho x, y, yaw
        pose_cov = [0.0] * 36
        pose_cov[0] = 0.01  # x
        pose_cov[7] = 0.01  # y
        pose_cov[35] = 0.2  # yaw
        odom.pose.covariance = pose_cov

        twist_cov = [0.0] * 36
        twist_cov[0] = 0.01 # vx
        twist_cov[35] = 0.1 # vyaw
        odom.twist.covariance = twist_cov

        self.pub_odom.publish(odom)

    def euler_to_quaternion(self, roll, pitch, yaw):
        qx = math.sin(roll/2) * math.cos(pitch/2) * math.cos(yaw/2) - math.cos(roll/2) * math.sin(pitch/2) * math.sin(yaw/2)
        qy = math.cos(roll/2) * math.sin(pitch/2) * math.cos(yaw/2) + math.sin(roll/2) * math.cos(pitch/2) * math.sin(yaw/2)
        qz = math.cos(roll/2) * math.cos(pitch/2) * math.sin(yaw/2) - math.sin(roll/2) * math.sin(pitch/2) * math.cos(yaw/2)
        qw = math.cos(roll/2) * math.cos(pitch/2) * math.cos(yaw/2) + math.sin(roll/2) * math.sin(pitch/2) * math.sin(yaw/2)
        msg_q = Quaternion()
        msg_q.x = qx; msg_q.y = qy; msg_q.z = qz; msg_q.w = qw
        return msg_q

def main(args=None):
    rclpy.init(args=args)
    node = RealRobotDriver()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
