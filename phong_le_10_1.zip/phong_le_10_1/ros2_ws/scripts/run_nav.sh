#!/bin/bash
echo "=== KHOI DONG NAVIGATION (DAN DUONG) ==="

source /opt/ros/jazzy/setup.bash
source install/setup.bash

# Mac dinh la my_map neu khong truyen tham so, hoac go ten map
MAP_NAME=${1:-my_map}
MAP_FILE=$(pwd)/maps/$MAP_NAME.yaml

if [ ! -f "$MAP_FILE" ]; then
    echo "[LOI] Khong tim thay file map: $MAP_FILE"
    echo "Hay kiem tra lai ten file trong thu muc maps/"
    exit 1
fi

echo "[INFO] Dang tai ban do: $MAP_FILE"

# Chay launch file nav va truyen duong dan map vao
ros2 launch my_robot_bringup nav.launch.py map:=$MAP_FILE
