#!/bin/bash
echo "=== KHOI DONG ROBOT ==="

# 1. Cap quyen USB (Mat khau sudo co the duoc hoi)
echo "[INFO] Cap quyen truy cap cong USB..."
sudo chmod 777 /dev/ttyUSB* 2>/dev/null || true
sudo chmod 777 /dev/ttyACM* 2>/dev/null || true

# 2. Hien thi cac thiet bi dang ket noi de kiem tra
echo "[INFO] Cac thiet bi dang ket noi:"
ls -l /dev/ttyUSB* /dev/ttyACM* 2>/dev/null

# 3. Source moi truong ROS 2
source /opt/ros/jazzy/setup.bash
source install/setup.bash

# --- [QUAN TRỌNG] FIX LỖI NAV2 KHÔNG TÌM THẤY ROBOT ---
# Nav2 yeu cau 'base_footprint', nhung robot chi co 'base_link'.
# Lenh nay tao mot 'ao anh' rang 2 cai la mot.
#echo "[INFO] Dang tao Static Transform base_link -> base_footprint..."
#ros2 run tf2_ros static_transform_publisher --frame-id base_link --child-frame-id base_footprint --x 0 --y 0 --z 0 --roll 0 --pitch 0 --yaw 0 &
# ------------------------------------------------------

# 4. Chay Launch file (Robot Driver, Lidar, TF...)
echo "[INFO] Dang chay launch file..."
ros2 launch my_robot_bringup bringup.launch.py
