#!/bin/bash
echo "=== BAT DAU CLEAN VA BUILD ==="

# Xoa cac thu muc build cu de tranh loi cache
rm -rf build/ install/ log/

# Build code
colcon build --symlink-install

# Nap lai moi truong
source install/setup.bash

echo "=== BUILD THANH CONG! ==="