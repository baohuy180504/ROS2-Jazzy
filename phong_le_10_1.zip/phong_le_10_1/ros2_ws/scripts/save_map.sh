#!/bin/bash
echo "=== LUU BAN DO (MAP SAVER) ==="

# 1. Source moi truong
source /opt/ros/jazzy/setup.bash
source install/setup.bash

# 2. Tao thu muc maps neu chua co
mkdir -p maps

# 3. Kiem tra xem nguoi dung co nhap ten khong
if [ -z "$1" ]; then
    # Neu khong nhap ten -> Tu dong dat ten theo gio he thong
    MAP_NAME="map_$(date +%Y%m%d_%H%M%S)"
    echo "[INFO] Ban khong nhap ten, tu dong dat ten la: $MAP_NAME"
else
    # Neu co nhap ten -> Dung ten do
    MAP_NAME=$1
fi

# 4. Goi lenh luu map
# Luu vao thu muc maps/
ros2 run nav2_map_server map_saver_cli -f maps/$MAP_NAME

echo "-------------------------------------------"
echo "[THANH CONG] Da luu 2 file tai:"
echo "   1. maps/$MAP_NAME.pgm (Hinh anh)"
echo "   2. maps/$MAP_NAME.yaml (Cau hinh)"
echo "-------------------------------------------"
