# AMR Robot Project - ROS 2 on Raspberry Pi 5

Dự án robot tự hành sử dụng **Raspberry Pi 5** chạy **ROS 2** (Humble/Jazzy), Arduino để điều khiển động cơ, và Lidar để định vị/tạo bản đồ (SLAM). Dự án đã được tích hợp các script tự động hóa để vận hành dễ dàng.

## 1. Cấu trúc phần cứng
*   **Máy tính nhúng:** Raspberry Pi 5.
*   **Vi điều khiển:** Arduino (Uno/Nano/Mega) - Giao tiếp qua Serial.
*   **Cảm biến:** Lidar (RPLidar A1/A2/A3...) - Giao tiếp qua USB.
*   **Driver động cơ:** L298N / TB6612 / BTS7960.

## 2. Cài đặt & Chuẩn bị

### 2.1. Cài đặt các gói phụ thuộc
Chạy các lệnh sau trên Raspberry Pi để cài đặt các thư viện ROS 2 cần thiết (chỉ cần chạy 1 lần đầu):

```bash
sudo apt update
sudo apt install ros-humble-navigation2 ros-humble-nav2-bringup ros-humble-slam-toolbox ros-humble-xacro ros-humble-robot-state-publisher
# Lưu ý: Thay 'humble' bằng 'jazzy' hoặc 'iron' tùy phiên bản ROS 2 bạn đang dùng.
```

### 2.2. Cấp quyền cho các Script tự động
Đảm bảo bạn đã tạo các file `.sh` (build.sh, start_robot.sh, v.v.) ở thư mục gốc của workspace (`~/phong_le_10_1/ros2_ws/`). Sau đó cấp quyền thực thi cho chúng:

```bash
cd ~/phong_le_10_1/ros2_ws
chmod +x *.sh
```

### 2.3. Build Workspace
Mỗi khi bạn sửa code hoặc thay đổi cấu hình, hãy chạy script này để xóa build cũ và biên dịch lại sạch sẽ:

```bash
./scripts/build.sh
```

---

## 3. Quy trình Vận hành (Sử dụng Script)

### Bước 1: Khởi động hệ thống (Bringup)
Script này sẽ tự động **cấp quyền USB** (bạn có thể cần nhập mật khẩu sudo) và khởi động toàn bộ hệ thống (Arduino, Lidar, Fake Odom, URDF).

**Terminal 1:**
```bash
./scripts/start_robot.sh
```
> **Kiểm tra:** Nếu không thấy dòng chữ đỏ `ERROR` nào và Lidar bắt đầu quay, hệ thống đã sẵn sàng.

---

### Bước 2: Điều khiển Robot (Teleop)
Mở một terminal mới và chạy script để bật bàn phím điều khiển:

**Terminal 2:**
```bash
./scripts/run_teleop.sh
```
*   **Điều khiển:** Sử dụng các phím `i`, `j`, `k`, `l` để di chuyển.
*   **Tốc độ:** Nhấn `q` hoặc `z` để tăng/giảm tốc độ.

---

### Bước 3: Kiểm tra Lidar (Tùy chọn)
Nếu muốn chắc chắn Lidar đang gửi dữ liệu, mở terminal mới:

```bash
ros2 topic hz /scan
```
Nếu thấy hiển thị `average rate: 10.xxx` nghĩa là ổn.

---

### Bước 4: Chạy SLAM & Lưu Bản Đồ

**1. Bật thuật toán SLAM:**
Mở terminal mới (giữ nguyên Terminal 1 và 2):

**Terminal 3:**
```bash
./scripts/run_slam.sh
```

**2. Theo dõi trên Laptop:**
*   Mở **RViz2** trên Laptop (kết nối cùng Wifi).
*   Add Topic `/map` và `/scan`.
*   Dùng **Terminal 2 (Teleop)** lái robot đi khắp phòng để vẽ kín bản đồ.

**3. Lưu bản đồ:**
Khi bản đồ đã đẹp, mở terminal mới để lưu lại.

**Terminal 4:**
```bash
# Cách 1: Tự động đặt tên theo ngày giờ
./scripts/save_map.sh

# Cách 2: Tự đặt tên (ví dụ: phong_khach)
./scripts/save_map.sh phong_khach
```
> Bản đồ sẽ được lưu vào thư mục `maps/` trong workspace.

---

### Bước 5: Chạy Navigation (Dẫn đường tự động)

Sau khi đã có bản đồ, tắt hết các terminal cũ (Ctrl+C).

**1. Khởi động lại Robot:**
**Terminal 1:**
```bash
./scripts/start_robot.sh
```

**2. Bật Navigation:**
Chạy script nav và trỏ đến tên bản đồ bạn muốn dùng (không cần đuôi .yaml).

**Terminal 2:**
```bash
# Nếu không nhập tên, mặc định sẽ tìm file 'my_map.yaml'
./scripts/run_nav.sh phong_khach
```

**3. Thao tác trên RViz (Laptop):**
*   **2D Pose Estimate:** Chấm vị trí robot hiện tại trên bản đồ cho khớp thực tế.
*   **Nav2 Goal:** Chọn điểm đích, robot sẽ tự tìm đường đi tới đó.

---

## 4. Xử lý lỗi thường gặp (Troubleshooting)

1.  **Lỗi `Failed to open serial port` khi chạy `./scripts/start_robot.sh`:**
    *   Script đã tự động `chmod 777`, nhưng hãy kiểm tra xem dây cáp có bị lỏng không.
    *   Kiểm tra xem tên cổng trong `bringup.launch.py` (ví dụ `/dev/ttyUSB0`) có khớp với thực tế không (kiểm tra bằng `ls /dev/tty*`).

2.  **Robot đi không thẳng hoặc bản đồ bị méo:**
    *   Do đang dùng `fake_odom` (giả lập vị trí từ lệnh điều khiển). Nếu bánh xe bị trượt hoặc động cơ lệch, bản đồ sẽ sai.
    *   **Khắc phục:** Cần gắn Encoder thực tế cho bánh xe.

3.  **Lỗi `command not found`:**
    *   Đảm bảo bạn đang đứng đúng thư mục workspace (`~/phong_le_10_1/ros2_ws`).
    *   Đảm bảo đã cấp quyền thực thi: `chmod +x *.sh`.