#!/bin/bash

# Dung script ngay neu gap loi (tot de debug)
set -e

echo "========================================"
echo " SETUP ROS 2 HUMBLE ON RASPBERRY PI 5 "
echo "   (Target OS: Ubuntu 22.04 Jammy)    "
echo "========================================"

# --------- 0. Check OS Version ---------
# Kiem tra xem co phai Ubuntu 22.04 khong (ROS 2 Humble chi ho tro tot nhat Ubuntu 22.04)
if [ -f /etc/os-release ]; then
    . /etc/os-release
    if [[ "$UBUNTU_CODENAME" != "jammy" ]]; then
        echo "[WARNING] Ban dang khong su dung Ubuntu 22.04 (Jammy)."
        echo "          Phien ban hien tai: $VERSION_CODENAME"
        echo "          Script co the gap loi neu ban dang dung Raspberry Pi OS (Bookworm)."
        echo "          Nhan Ctrl+C de huy hoac Enter de tiep tuc..."
        read
    fi
fi

# --------- 1. Update system ----------
echo "[1/7] Updating system..."
sudo apt update && sudo apt upgrade -y

# --------- 2. Locale ----------
echo "[2/7] Setting locale..."
sudo apt install -y locales
sudo locale-gen en_US en_US.UTF-8
sudo update-locale LC_ALL=en_US.UTF-8 LANG=en_US.UTF-8
export LANG=en_US.UTF-8

# --------- 3. ROS 2 repository ----------
echo "[3/7] Adding ROS 2 repository..."
sudo apt install -y software-properties-common curl gnupg lsb-release

# Them key
sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key \
  -o /usr/share/keyrings/ros-archive-keyring.gpg

# Them repo
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] \
http://packages.ros.org/ros2/ubuntu $(lsb_release -cs) main" | \
sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null

sudo apt update

# --------- 4. Install ROS 2 & Dependencies ----------
echo "[4/7] Installing ROS 2 Humble & Robot Libraries..."
# Desktop: Bao gom ca RViz va cac cong cu GUI
sudo apt install -y \
  ros-humble-desktop \
  ros-humble-navigation2 \
  ros-humble-nav2-bringup \
  ros-humble-slam-toolbox \
  ros-humble-robot-state-publisher \
  ros-humble-joint-state-publisher \
  ros-humble-xacro \
  ros-humble-teleop-twist-keyboard \
  ros-humble-ros2-control \
  ros-humble-ros2-controllers \
  libserial-dev \
  python3-serial

# libserial-dev: Can thiet neu ban viet driver C++ giao tiep Serial
# python3-serial: Can thiet neu ban dung Python

# --------- 5. Development tools ----------
echo "[5/7] Installing development tools..."
sudo apt install -y \
  python3-colcon-common-extensions \
  python3-rosdep \
  python3-vcstool \
  build-essential \
  git \
  minicom \
  nano \
  htop \
  net-tools

# --------- 6. User Permissions (QUAN TRONG) ----------
echo "[6/7] Configuring User Permissions (USB/Serial)..."
# Them user hien tai vao nhom dialout de doc cong USB ma khong can sudo
sudo usermod -aG dialout $USER
echo "Added user $USER to 'dialout' group."

# --------- 7. rosdep & Workspace ----------
echo "[7/7] Initializing rosdep & Workspace..."
if [ ! -f /etc/ros/rosdep/sources.list.d/20-default.list ]; then
    sudo rosdep init
fi
rosdep update

# Tao workspace neu chua co
mkdir -p ~/ros2_ws/src

# --------- 8. Bashrc Configuration ----------
echo "Configuring ~/.bashrc..."

# Ham them dong vao bashrc neu chua ton tai
add_to_bashrc() {
    if ! grep -qF "$1" ~/.bashrc; then
        echo "$1" >> ~/.bashrc
        echo "Added: $1"
    fi
}

add_to_bashrc "source /opt/ros/humble/setup.bash"
add_to_bashrc "source ~/ros2_ws/install/setup.bash"
add_to_bashrc "export ROS_DOMAIN_ID=0"
add_to_bashrc "export RMW_IMPLEMENTATION=rmw_fastrtps_cpp"

# Alias tien loi (Tuy chon)
add_to_bashrc "alias cb='colcon build --symlink-install'"
add_to_bashrc "alias s='source install/setup.bash'"

echo "========================================"
echo " SETUP COMPLETED SUCCESSFULLY "
echo "----------------------------------------"
echo " QUAN TRONG: Ban can khoi dong lai Pi de ap dung quyen USB!"
echo " Hay chay: sudo reboot"
echo "========================================"