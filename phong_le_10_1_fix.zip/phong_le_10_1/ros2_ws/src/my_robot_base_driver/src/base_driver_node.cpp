#include <rclcpp/rclcpp.hpp>
#include <geometry_msgs/msg/twist.hpp>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <cstring>
#include <iostream>

class BaseDriverNode : public rclcpp::Node {
public:
    BaseDriverNode() : Node("base_driver_node") {
        // Declare parameters
        this->declare_parameter<std::string>("port", "/dev/ttyUSB0");
        this->declare_parameter<int>("baudrate", 115200);

        std::string port_name = this->get_parameter("port").as_string();
        int baudrate = this->get_parameter("baudrate").as_int();

        // Open Serial
        if (!setup_serial(port_name, baudrate)) {
            RCLCPP_ERROR(this->get_logger(), "Failed to open serial port: %s", port_name.c_str());
        } else {
            RCLCPP_INFO(this->get_logger(), "Connected to serial: %s", port_name.c_str());
        }

        // Subscriber
        subscription_ = this->create_subscription<geometry_msgs::msg::Twist>(
            "cmd_vel", 10, std::bind(&BaseDriverNode::cmd_vel_callback, this, std::placeholders::_1));
    }

    ~BaseDriverNode() {
        if (serial_fd_ != -1) close(serial_fd_);
    }

private:
    int serial_fd_ = -1;
    rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr subscription_;

    bool setup_serial(const std::string &port, int baud) {
        serial_fd_ = open(port.c_str(), O_RDWR | O_NOCTTY | O_NDELAY);
        if (serial_fd_ == -1) return false;

        struct termios options;
        tcgetattr(serial_fd_, &options);
        
        // Set baudrate (simple switch for common rates)
        speed_t speed = (baud == 115200) ? B115200 : B9600;
        cfsetispeed(&options, speed);
        cfsetospeed(&options, speed);

        options.c_cflag |= (CLOCAL | CREAD);
        options.c_cflag &= ~PARENB;
        options.c_cflag &= ~CSTOPB;
        options.c_cflag &= ~CSIZE;
        options.c_cflag |= CS8;
        
        tcsetattr(serial_fd_, TCSANOW, &options);
        return true;
    }

    void cmd_vel_callback(const geometry_msgs::msg::Twist::SharedPtr msg) {
        if (serial_fd_ == -1) return;

        char buffer[50];
        // Format: "linear_x,angular_z\n"
        int len = sprintf(buffer, "%.2f,%.2f\n", msg->linear.x, msg->angular.z);
        write(serial_fd_, buffer, len);
    }
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<BaseDriverNode>());
    rclcpp::shutdown();
    return 0;
}