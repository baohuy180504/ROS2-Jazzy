import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    
    # Paths
    desc_pkg = get_package_share_directory('amr_description')
    urdf_file = os.path.join(desc_pkg, 'urdf', 'amr.urdf')
    
    # Lidar Driver (Ví dụ dùng sllidar_ros2 cho RPLidar A1/A2)
    # Cần cài: sudo apt install ros-<distro>-sllidar-ros2
    # Lidar Driver
    lidar_node = Node(
        package='sllidar_ros2',
        executable='sllidar_node',
        name='sllidar_node',
        parameters=[{
            'channel_type': 'serial',
            'serial_port': '/dev/ttyUSB0', 
            'serial_baudrate': 115200,      # <--- QUAN TRỌNG: Phải set cứng là 115200 cho A1M8
            'frame_id': 'laser_frame',
            'inverted': False,
            'angle_compensate': True,
            'scan_mode': 'Sensitivity'      # Chế độ quét chuẩn của A1
        }],
        output='screen'
    )
    

    # Robot State Publisher (Đọc URDF phát TF tĩnh)
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        arguments=[urdf_file]
    )

    # Base Driver (Giao tiếp Arduino)
    base_driver = Node(
        package='my_robot_base_driver',
        executable='base_driver_node',
        name='base_driver',
        parameters=[{'port': '/dev/ttyACM0', 'baudrate': 115200}], # Check cổng này
        output='screen'
    )

    # Fake Odom (Tính toán Odom từ cmd_vel)
    fake_odom = Node(
        package='amr_fake_odom',
        executable='fake_odom_node',
        name='fake_odom',
        output='screen'
    )

    return LaunchDescription([
        robot_state_publisher,
        base_driver,
        fake_odom,
        lidar_node
    ])
