#!/bin/bash
echo "=== KHOI DONG ROBOT ==="

# 1. Cap quyen USB (Mat khau sudo co the duoc hoi)
echo "[INFO] Cap quyen truy cap cong USB..."
sudo chmod 777 /dev/ttyUSB* 2>/dev/null || true
sudo chmod 777 /dev/ttyACM* 2>/dev/null || true

# 2. Hien thi cac thiet bi dang ket noi de kiem tra
echo "[INFO] Cac thiet bi dang ket noi:"
ls -l /dev/ttyUSB* /dev/ttyACM* 2>/dev/null

# 3. Source moi truong ROS 2
source /opt/ros/jazzy/setup.bash
source install/setup.bash

# 4. Chay Launch file
echo "[INFO] Dang chay launch file..."
ros2 launch my_robot_bringup bringup.launch.py
